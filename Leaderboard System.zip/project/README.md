# Leaderboard System

A full-stack leaderboard application built with React, Node.js, Express, and MongoDB.

## Features

- **User Management**: Add new users dynamically and manage existing users
- **Point Claiming**: Claim random points (1-10) for selected users
- **Real-time Leaderboard**: Dynamic rankings that update automatically
- **Claim History**: Track all point claims with detailed history
- **Beautiful UI**: Modern, responsive design with smooth animations
- **Real-time Updates**: Automatic data refresh every 30 seconds

## Tech Stack

### Frontend
- React 18 with TypeScript
- Tailwind CSS for styling
- Lucide React for icons
- Custom hooks for state management

### Backend
- Node.js with Express
- MongoDB with Mongoose ODM
- RESTful API design
- Error handling middleware

### Database Schema

#### Users Collection
```javascript
{
  name: String (required, unique),
  totalPoints: Number (default: 0),
  rank: Number (default: 0),
  createdAt: Date,
  updatedAt: Date
}
```

#### Claim History Collection
```javascript
{
  userId: ObjectId (ref: User),
  userName: String,
  pointsClaimed: Number (1-10),
  totalPointsAfterClaim: Number,
  claimedAt: Date
}
```

## Installation & Setup

### Prerequisites
- Node.js (v16 or higher)
- MongoDB (local or cloud instance)
- npm or yarn

### 1. Clone the Repository
```bash
git clone <repository-url>
cd leaderboard-system
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Environment Configuration
Create a `.env` file in the root directory:
```env
MONGODB_URI=mongodb://localhost:27017/leaderboard
PORT=5000
NODE_ENV=development
```

### 4. Start MongoDB
Make sure MongoDB is running on your system:
```bash
# For local MongoDB installation
mongod
```

### 5. Start the Application
```bash
# Start both frontend and backend concurrently
npm run dev

# Or start them separately:
# Frontend only
npm run client

# Backend only
npm run server
```

The application will be available at:
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000

## API Endpoints

### Users
- `GET /api/users` - Get all users with rankings
- `POST /api/users` - Add a new user

### Points
- `POST /api/claim-points` - Claim random points for a user

### History
- `GET /api/claim-history` - Get claim history (with limit parameter)

### Health Check
- `GET /api/health` - API health check

## Project Structure

```
leaderboard-system/
├── server/
│   ├── config/
│   │   └── database.js
│   ├── controllers/
│   │   └── userController.js
│   ├── models/
│   │   ├── User.js
│   │   └── ClaimHistory.js
│   ├── routes/
│   │   └── userRoutes.js
│   └── server.js
├── src/
│   ├── components/
│   │   ├── Header.tsx
│   │   ├── UserSelection.tsx
│   │   ├── ClaimButton.tsx
│   │   ├── Leaderboard.tsx
│   │   ├── ClaimHistory.tsx
│   │   └── Toast.tsx
│   ├── hooks/
│   │   └── useToast.ts
│   ├── services/
│   │   └── api.ts
│   ├── types/
│   │   └── index.ts
│   └── App.tsx
├── .env
├── package.json
└── README.md
```

## Features Overview

### User Selection
- Dropdown list of all users
- Add new users functionality
- Real-time user data updates

### Point Claiming
- Random point generation (1-10)
- Instant feedback with toast notifications
- Automatic leaderboard updates

### Dynamic Leaderboard
- Real-time ranking calculations
- Beautiful rank indicators (Crown, Trophy, Medal)
- Smooth animations and transitions

### Claim History
- Chronological list of all claims
- User-specific claim details
- Scrollable history with recent claims first

### Responsive Design
- Mobile-first approach
- Tablet and desktop optimized
- Beautiful glassmorphism effects

## Development

### Code Quality
- TypeScript for type safety
- ESLint for code linting
- Consistent code formatting
- Comprehensive error handling

### Best Practices
- Modular component architecture
- Custom hooks for reusable logic
- API service layer abstraction
- Proper error boundaries

## Database Seeding

The application automatically seeds 10 initial users when the database is empty:
- Rahul, Kamal, Sanak, Priya, Arjun, Anita, Vikram, Sneha, Raj, Maya

## Performance Features

- Auto-refresh every 30 seconds
- Optimized API calls
- Efficient MongoDB queries
- Responsive UI components

## Troubleshooting

### Common Issues

1. **MongoDB Connection Error**
   - Ensure MongoDB is running
   - Check the connection string in `.env`

2. **Port Already in Use**
   - Change the PORT in `.env` file
   - Kill existing processes using the ports

3. **Dependencies Issues**
   - Delete `node_modules` and run `npm install`
   - Clear npm cache: `npm cache clean --force`

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License.