const express = require('express');
const router = express.Router();
const {
  getAllUsers,
  addUser,
  claimPoints,
  getClaimHistory
} = require('../controllers/userController');

// Get all users
router.get('/users', getAllUsers);

// Add new user
router.post('/users', addUser);

// Claim points
router.post('/claim-points', claimPoints);

// Get claim history
router.get('/claim-history', getClaimHistory);

module.exports = router;