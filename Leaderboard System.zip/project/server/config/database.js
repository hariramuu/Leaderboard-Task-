const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/leaderboard', {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log(`MongoDB Connected: ${conn.connection.host}`);
    
    // Seed initial users if the database is empty
    await seedUsers();
    
  } catch (error) {
    console.error('Error connecting to MongoDB:', error.message);
    process.exit(1);
  }
};

const seedUsers = async () => {
  const User = require('../models/User');
  
  try {
    const userCount = await User.countDocuments();
    
    if (userCount === 0) {
      console.log('Seeding initial users...');
      
      const initialUsers = [
        { name: 'Rahul', totalPoints: 0 },
        { name: 'Kamal', totalPoints: 0 },
        { name: 'Sanak', totalPoints: 0 },
        { name: 'Priya', totalPoints: 0 },
        { name: 'Arjun', totalPoints: 0 },
        { name: 'Anita', totalPoints: 0 },
        { name: 'Vikram', totalPoints: 0 },
        { name: 'Sneha', totalPoints: 0 },
        { name: 'Raj', totalPoints: 0 },
        { name: 'Maya', totalPoints: 0 }
      ];

      await User.insertMany(initialUsers);
      console.log('Initial users seeded successfully!');
    }
  } catch (error) {
    console.error('Error seeding users:', error.message);
  }
};

module.exports = connectDB;