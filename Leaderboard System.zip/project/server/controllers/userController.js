const User = require('../models/User');
const ClaimHistory = require('../models/ClaimHistory');

// Get all users with rankings
const getAllUsers = async (req, res) => {
  try {
    const users = await User.find().sort({ totalPoints: -1 });
    
    // Update rankings
    users.forEach((user, index) => {
      user.rank = index + 1;
    });

    // Save updated rankings
    await Promise.all(users.map(user => user.save()));
    
    res.json({
      success: true,
      data: users
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching users',
      error: error.message
    });
  }
};

// Add a new user
const addUser = async (req, res) => {
  try {
    const { name } = req.body;
    
    if (!name || name.trim() === '') {
      return res.status(400).json({
        success: false,
        message: 'User name is required'
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ name: name.trim() });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User with this name already exists'
      });
    }

    const newUser = new User({
      name: name.trim()
    });

    await newUser.save();
    
    res.status(201).json({
      success: true,
      message: 'User added successfully',
      data: newUser
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error adding user',
      error: error.message
    });
  }
};

// Claim points for a user
const claimPoints = async (req, res) => {
  try {
    const { userId } = req.body;
    
    if (!userId) {
      return res.status(400).json({
        success: false,
        message: 'User ID is required'
      });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Generate random points between 1 and 10
    const pointsClaimed = Math.floor(Math.random() * 10) + 1;
    
    // Update user's total points
    user.totalPoints += pointsClaimed;
    await user.save();

    // Create claim history entry
    const claimHistory = new ClaimHistory({
      userId: user._id,
      userName: user.name,
      pointsClaimed,
      totalPointsAfterClaim: user.totalPoints
    });
    await claimHistory.save();

    res.json({
      success: true,
      message: `${pointsClaimed} points claimed successfully!`,
      data: {
        user,
        pointsClaimed,
        claimHistory
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error claiming points',
      error: error.message
    });
  }
};

// Get claim history
const getClaimHistory = async (req, res) => {
  try {
    const { limit = 50 } = req.query;
    
    const history = await ClaimHistory
      .find()
      .sort({ claimedAt: -1 })
      .limit(parseInt(limit));
    
    res.json({
      success: true,
      data: history
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching claim history',
      error: error.message
    });
  }
};

module.exports = {
  getAllUsers,
  addUser,
  claimPoints,
  getClaimHistory
};