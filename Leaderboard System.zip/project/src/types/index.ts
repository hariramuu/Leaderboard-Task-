export interface User {
  _id: string;
  name: string;
  totalPoints: number;
  rank: number;
  createdAt: string;
  updatedAt: string;
}

export interface ClaimHistory {
  _id: string;
  userId: string;
  userName: string;
  pointsClaimed: number;
  totalPointsAfterClaim: number;
  claimedAt: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  data: T;
  error?: string;
}