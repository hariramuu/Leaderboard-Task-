import React from 'react';
import { Trophy, Gamepad2 } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <div className="text-center mb-8">
      <div className="flex items-center justify-center gap-3 mb-4">
        <div className="p-3 bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl shadow-lg">
          <Gamepad2 className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          Leaderboard System
        </h1>
      </div>
      
      <p className="text-lg text-gray-600 max-w-2xl mx-auto">
        Select a user, claim random points, and watch the rankings update in real-time!
      </p>
      
      <div className="flex items-center justify-center gap-6 mt-6 text-sm text-gray-500">
        <div className="flex items-center gap-2">
          <Trophy className="w-4 h-4 text-yellow-500" />
          <span>Dynamic Rankings</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-gradient-to-r from-green-400 to-green-600 rounded-full"></div>
          <span>Random Points (1-10)</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full"></div>
          <span>Real-time Updates</span>
        </div>
      </div>
    </div>
  );
};

export default Header;