import React from 'react';
import { ClaimHistory } from '../types';
import { History, Clock, Gift } from 'lucide-react';

interface ClaimHistoryProps {
  history: ClaimHistory[];
  isLoading?: boolean;
}

const ClaimHistoryComponent: React.FC<ClaimHistoryProps> = ({ history, isLoading = false }) => {
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
    return (
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-white/20">
        <div className="flex items-center gap-3 mb-6">
          <History className="w-6 h-6 text-green-600" />
          <h2 className="text-xl font-bold text-gray-800">Recent Claims</h2>
        </div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse">
              <div className="h-12 bg-gray-200 rounded-lg"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-white/20">
      <div className="flex items-center gap-3 mb-6">
        <History className="w-6 h-6 text-green-600" />
        <h2 className="text-xl font-bold text-gray-800">Recent Claims</h2>
      </div>

      <div className="space-y-3 max-h-80 overflow-y-auto">
        {history.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Gift className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p>No claims yet. Start claiming points!</p>
          </div>
        ) : (
          history.map((claim) => (
            <div
              key={claim._id}
              className="flex items-center justify-between p-3 bg-white/50 rounded-lg border border-gray-100 hover:bg-white/70 transition-all duration-200"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center">
                  <Gift className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="font-medium text-gray-800">{claim.userName}</p>
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <Clock className="w-3 h-3" />
                    {formatTime(claim.claimedAt)}
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-lg font-bold text-green-600">
                  +{claim.pointsClaimed}
                </div>
                <div className="text-xs text-gray-500">
                  Total: {claim.totalPointsAfterClaim}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ClaimHistoryComponent;