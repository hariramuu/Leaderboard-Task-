import React from 'react';
import { Gift, Loader } from 'lucide-react';

interface ClaimButtonProps {
  selectedUserId: string;
  onClaimPoints: () => void;
  isLoading?: boolean;
}

const ClaimButton: React.FC<ClaimButtonProps> = ({
  selectedUserId,
  onClaimPoints,
  isLoading = false
}) => {
  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-white/20">
      <div className="text-center">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Gift className="w-6 h-6 text-purple-600" />
          <h2 className="text-xl font-bold text-gray-800">Claim Points</h2>
        </div>
        
        <p className="text-gray-600 mb-6">
          Click the button below to claim random points (1-10) for the selected user!
        </p>
        
        <button
          onClick={onClaimPoints}
          disabled={!selectedUserId || isLoading}
          className={`
            w-full px-8 py-4 rounded-xl font-bold text-lg transition-all duration-300 transform
            ${
              !selectedUserId || isLoading
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700 hover:scale-105 active:scale-95 shadow-lg hover:shadow-xl'
            }
          `}
        >
          <div className="flex items-center justify-center gap-3">
            {isLoading ? (
              <>
                <Loader className="w-6 h-6 animate-spin" />
                Claiming Points...
              </>
            ) : (
              <>
                <Gift className="w-6 h-6" />
                Claim Random Points
              </>
            )}
          </div>
        </button>
        
        {!selectedUserId && (
          <p className="text-sm text-red-500 mt-3">
            Please select a user first!
          </p>
        )}
      </div>
    </div>
  );
};

export default ClaimButton;