import React from 'react';
import { User } from '../types';
import { Trophy, Medal, Award, Crown } from 'lucide-react';

interface LeaderboardProps {
  users: User[];
  isLoading?: boolean;
}

const Leaderboard: React.FC<LeaderboardProps> = ({ users, isLoading = false }) => {
  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-6 h-6 text-yellow-500" />;
      case 2:
        return <Trophy className="w-6 h-6 text-gray-400" />;
      case 3:
        return <Medal className="w-6 h-6 text-amber-600" />;
      default:
        return <Award className="w-5 h-5 text-gray-400" />;
    }
  };

  const getRankStyle = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-400 to-yellow-600 text-white';
      case 2:
        return 'bg-gradient-to-r from-gray-300 to-gray-500 text-white';
      case 3:
        return 'bg-gradient-to-r from-amber-400 to-amber-600 text-white';
      default:
        return 'bg-white/60 text-gray-700 border border-gray-200';
    }
  };

  if (isLoading) {
    return (
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-white/20">
        <div className="flex items-center gap-3 mb-6">
          <Trophy className="w-6 h-6 text-yellow-600" />
          <h2 className="text-xl font-bold text-gray-800">Leaderboard</h2>
        </div>
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="animate-pulse">
              <div className="h-16 bg-gray-200 rounded-lg"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-white/20">
      <div className="flex items-center gap-3 mb-6">
        <Trophy className="w-6 h-6 text-yellow-600" />
        <h2 className="text-xl font-bold text-gray-800">Leaderboard</h2>
      </div>

      <div className="space-y-3">
        {users.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Trophy className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p>No users found. Add some users to get started!</p>
          </div>
        ) : (
          users.map((user, index) => (
            <div
              key={user._id}
              className={`
                flex items-center justify-between p-4 rounded-xl transition-all duration-300 transform hover:scale-102
                ${getRankStyle(user.rank || index + 1)}
              `}
            >
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  {getRankIcon(user.rank || index + 1)}
                  <span className="font-bold text-lg">#{user.rank || index + 1}</span>
                </div>
                <div>
                  <h3 className="font-semibold text-lg">{user.name}</h3>
                  <p className={`text-sm ${user.rank <= 3 ? 'text-white/80' : 'text-gray-500'}`}>
                    Total Points
                  </p>
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-2xl font-bold">
                  {user.totalPoints}
                </div>
                <div className={`text-xs ${user.rank <= 3 ? 'text-white/60' : 'text-gray-400'}`}>
                  points
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {users.length > 0 && (
        <div className="mt-4 pt-4 border-t border-gray-200">
          <p className="text-sm text-gray-500 text-center">
            Rankings update automatically after each point claim
          </p>
        </div>
      )}
    </div>
  );
};

export default Leaderboard;