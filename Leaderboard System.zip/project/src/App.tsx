import React, { useState, useEffect, useCallback } from 'react';
import { User, ClaimHistory, ApiResponse } from './types';
import { ApiService } from './services/api';
import { useToast } from './hooks/useToast';
import Header from './components/Header';
import UserSelection from './components/UserSelection';
import ClaimButton from './components/ClaimButton';
import Leaderboard from './components/Leaderboard';
import ClaimHistoryComponent from './components/ClaimHistory';
import Toast from './components/Toast';

function App() {
  const [users, setUsers] = useState<User[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [claimHistory, setClaimHistory] = useState<ClaimHistory[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isClaimingPoints, setIsClaimingPoints] = useState(false);
  const { toast, showSuccess, showError, hideToast } = useToast();

  // Fetch all users
  const fetchUsers = useCallback(async () => {
    try {
      setIsLoading(true);
      const response: ApiResponse<User[]> = await ApiService.getAllUsers();
      if (response.success) {
        setUsers(response.data);
      } else {
        showError('Failed to fetch users');
      }
    } catch (error) {
      console.error('Error fetching users:', error);
      showError('Failed to connect to server. Please make sure the backend is running.');
    } finally {
      setIsLoading(false);
    }
  }, [showError]);

  // Fetch claim history
  const fetchClaimHistory = useCallback(async () => {
    try {
      const response: ApiResponse<ClaimHistory[]> = await ApiService.getClaimHistory(20);
      if (response.success) {
        setClaimHistory(response.data);
      }
    } catch (error) {
      console.error('Error fetching claim history:', error);
    }
  }, []);

  // Add new user
  const handleAddUser = async (name: string) => {
    try {
      const response: ApiResponse<User> = await ApiService.addUser(name);
      if (response.success) {
        showSuccess(`User "${name}" added successfully!`);
        await fetchUsers();
      } else {
        showError(response.message || 'Failed to add user');
      }
    } catch (error: any) {
      console.error('Error adding user:', error);
      showError(error.message || 'Failed to add user');
    }
  };

  // Claim points
  const handleClaimPoints = async () => {
    if (!selectedUserId) {
      showWarning('Please select a user first!');
      return;
    }

    try {
      setIsClaimingPoints(true);
      const response: ApiResponse<any> = await ApiService.claimPoints(selectedUserId);
      
      if (response.success) {
        showSuccess(response.message || 'Points claimed successfully!');
        await fetchUsers();
        await fetchClaimHistory();
      } else {
        showError(response.message || 'Failed to claim points');
      }
    } catch (error: any) {
      console.error('Error claiming points:', error);
      showError(error.message || 'Failed to claim points');
    } finally {
      setIsClaimingPoints(false);
    }
  };

  // Initial data fetch
  useEffect(() => {
    fetchUsers();
    fetchClaimHistory();
  }, [fetchUsers, fetchClaimHistory]);

  // Auto-refresh data every 30 seconds for real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      if (!isClaimingPoints && !isLoading) {
        fetchUsers();
        fetchClaimHistory();
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [fetchUsers, fetchClaimHistory, isClaimingPoints, isLoading]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <Header />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - User Selection and Claim Button */}
          <div className="space-y-6">
            <UserSelection
              users={users}
              selectedUserId={selectedUserId}
              onUserSelect={setSelectedUserId}
              onAddUser={handleAddUser}
              isLoading={isLoading}
            />
            <ClaimButton
              selectedUserId={selectedUserId}
              onClaimPoints={handleClaimPoints}
              isLoading={isClaimingPoints}
            />
          </div>

          {/* Middle Column - Leaderboard */}
          <div>
            <Leaderboard users={users} isLoading={isLoading} />
          </div>

          {/* Right Column - Claim History */}
          <div>
            <ClaimHistoryComponent history={claimHistory} isLoading={isLoading} />
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center text-gray-500 text-sm">
          <p>© 2024 Leaderboard System. Built with React, Node.js, and MongoDB.</p>
          <p className="mt-1">Data refreshes automatically every 30 seconds for real-time updates.</p>
        </div>
      </div>

      {/* Toast Notification */}
      <Toast
        type={toast.type}
        message={toast.message}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </div>
  );
}

export default App;