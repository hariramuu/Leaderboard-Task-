const API_BASE_URL = 'http://localhost:5000/api';

export class ApiService {
  private static async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        ...options,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('API request failed:', error);
      throw error;
    }
  }

  static async getAllUsers() {
    return this.request('/users');
  }

  static async addUser(name: string) {
    return this.request('/users', {
      method: 'POST',
      body: JSON.stringify({ name }),
    });
  }

  static async claimPoints(userId: string) {
    return this.request('/claim-points', {
      method: 'POST',
      body: JSON.stringify({ userId }),
    });
  }

  static async getClaimHistory(limit = 50) {
    return this.request(`/claim-history?limit=${limit}`);
  }
}